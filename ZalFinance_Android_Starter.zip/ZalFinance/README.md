# Zal Finance — proyek awal Android

Ini adalah **starter project**, bukan APK siap instal. Integrasi Gmail belum aktif sampai OAuth Google dikonfigurasi dan implementasi API diselesaikan.

## Isi proyek
- Kotlin Android
- Room / SQLite untuk histori offline
- WorkManager untuk jadwal sinkronisasi berkala 15 menit
- Parser awal email transaksi
- Pencegahan duplikat melalui `sourceMessageId` unik

## Membuka proyek
1. Instal Android Studio di komputer.
2. Ekstrak ZIP ini.
3. Android Studio → Open → pilih folder `ZalFinance`.
4. Tunggu Gradle Sync.
5. Jalankan pada emulator atau HP Android dengan USB debugging.

## Mengaktifkan Gmail (wajib konfigurasi)
1. Buat project di Google Cloud Console.
2. Aktifkan Gmail API.
3. Konfigurasikan OAuth consent screen dan OAuth Client ID Android.
4. Tambahkan SHA-1/SHA-256 sertifikat aplikasi sesuai panduan Google.
5. Minta izin minimum `https://www.googleapis.com/auth/gmail.readonly`.
6. Implementasikan alur Google Sign-In/OAuth, token refresh aman, Gmail History API atau pencarian email baru, dan checkpoint.
7. Uji dengan email transaksi contoh yang telah disamarkan.

Jangan meminta atau menyimpan password Gmail, PIN bank, atau OTP. Jangan mengunggah isi email ke server pihak ketiga. OAuth token harus disimpan dengan mekanisme aman Android dan dapat dicabut pengguna.

## Batasan penting
- Android WorkManager memakai interval minimum 15 menit untuk periodic work; waktu eksekusi dapat ditunda oleh Doze, baterai, jaringan, dan kebijakan sistem.
- Gmail API membutuhkan koneksi internet. Database transaksi tetap lokal.
- Format email bank/e-wallet berbeda-beda. Parser harus disesuaikan dan diuji untuk tiap pengirim; jangan menganggap semua email dapat dipahami akurat oleh satu pola.
- Email refund, pembatalan, transfer antar rekening sendiri, dan transaksi pending perlu aturan khusus agar laporan tidak salah.
- Aplikasi ini belum memiliki integrasi Gmail aktif, layar login Google, kategori editor, grafik, ekspor, atau APK release.

## Versi
0.1.0 — kerangka awal untuk pengembangan.
