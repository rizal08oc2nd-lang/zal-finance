package id.zalfinance.app.sync

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/**
 * Kerangka worker. Integrasi Gmail OAuth dan Gmail API harus diaktifkan
 * setelah membuat OAuth Client ID milik aplikasi di Google Cloud Console.
 * Jangan menaruh client secret atau token di source code.
 */
class GmailSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        // TODO:
        // 1. Ambil token OAuth dari penyimpanan kredensial yang aman.
        // 2. Panggil Gmail API dengan scope gmail.readonly.
        // 3. Ambil email baru sejak historyId / checkpoint terakhir.
        // 4. Parse email menggunakan template pengirim yang dikenali.
        // 5. Simpan transaksi ke Room dengan sourceMessageId unik.
        // 6. Abaikan email yang bukan notifikasi transaksi.
        //
        // Belum menjalankan pembacaan Gmail agar tidak meminta akses sebelum
        // pengguna menghubungkan akun dan mengonfigurasi OAuth.
        return Result.success()
    }
}
