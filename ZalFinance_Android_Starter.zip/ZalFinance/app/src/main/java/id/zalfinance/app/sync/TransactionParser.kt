package id.zalfinance.app.sync

/**
 * Parser awal untuk email notifikasi transaksi.
 * Template email tiap bank berbeda; tambahkan pola berdasarkan contoh email
 * yang sudah disamarkan (hapus nama, nomor rekening, alamat, dan data rahasia).
 */
data class ParsedTransaction(
    val amount: Long,
    val description: String,
    val type: String,
    val category: String,
    val source: String
)

object TransactionParser {
    private val amountRegex = Regex(
        """(?:Rp\s?|IDR\s?)([0-9][0-9.,]*)""",
        RegexOption.IGNORE_CASE
    )

    fun parse(subject: String, body: String): ParsedTransaction? {
        val text = "$subject\n$body"
        val match = amountRegex.find(text) ?: return null
        val digits = match.groupValues[1].replace(".", "").replace(",", "")
        val amount = digits.toLongOrNull() ?: return null

        val lower = text.lowercase()
        val source = when {
            "qris" in lower -> "QRIS"
            listOf("dana", "ovo", "gopay", "shopeepay", "linkaja").any { it in lower } -> "EWALLET"
            listOf("shopee", "tokopedia", "lazada", "blibli").any { it in lower } -> "MARKETPLACE"
            listOf("listrik", "pln", "internet", "tagihan").any { it in lower } -> "BILL"
            else -> "BANK"
        }
        val income = listOf("diterima", "uang masuk", "kredit", "received", "berhasil menerima")
            .any { it in lower }
        val category = when {
            "qris" in lower || "makan" in lower || "resto" in lower -> "Makan & Minum"
            "bbm" in lower || "bensin" in lower || "transport" in lower -> "Transportasi"
            "listrik" in lower || "pln" in lower || "internet" in lower -> "Tagihan"
            source == "MARKETPLACE" -> "Belanja"
            else -> if (income) "Pemasukan" else "Lainnya"
        }
        return ParsedTransaction(
            amount = amount,
            description = subject.ifBlank { "Transaksi email" },
            type = if (income) "INCOME" else "EXPENSE",
            category = category,
            source = source
        )
    }
}
