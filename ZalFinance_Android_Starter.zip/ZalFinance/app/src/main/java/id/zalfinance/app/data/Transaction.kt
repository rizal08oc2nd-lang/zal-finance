package id.zalfinance.app.data

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "transactions",
    indices = [Index(value = ["sourceMessageId"], unique = true)]
)
data class Transaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceMessageId: String,
    val dateMillis: Long,
    val description: String,
    val amount: Long,
    val type: String,          // INCOME or EXPENSE
    val category: String,
    val source: String,        // BANK, EWALLET, QRIS, MARKETPLACE, BILL
    val sender: String = ""
)
