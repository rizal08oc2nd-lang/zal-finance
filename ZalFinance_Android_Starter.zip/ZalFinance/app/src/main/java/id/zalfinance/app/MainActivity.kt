package id.zalfinance.app

import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import id.zalfinance.app.data.AppDatabase
import id.zalfinance.app.sync.SyncScheduler
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SyncScheduler.schedule(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 32)
            gravity = Gravity.TOP
        }
        fun label(text: String, size: Float, bold: Boolean = false): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
                setPadding(0, 12, 0, 12)
            }

        root.addView(label("Zal Finance", 28f, true))
        root.addView(label("Ringkasan keuangan pribadi", 15f))
        val total = label("Memuat saldo…", 24f, true)
        root.addView(total)
        root.addView(label("Histori transaksi tersimpan di perangkat", 14f))
        root.addView(label("Sinkronisasi Gmail: dijadwalkan setiap 15 menit jika Android mengizinkan.", 14f))
        root.addView(label("Status: kerangka awal. Hubungkan Gmail setelah konfigurasi OAuth.", 13f))
        setContentView(root)

        lifecycleScope.launch {
            AppDatabase.get(this@MainActivity).transactionDao()
                .observeNetTotal().collect { amount ->
                    total.text = "Saldo bersih: Rp${"% ,d".format(amount).replace(',', '.')}"
                }
        }
    }
}
